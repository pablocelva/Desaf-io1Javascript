precio = 400000

precioSpan = document.querySelector(".precio-inicial");
precioSpan.innerHTML = precio